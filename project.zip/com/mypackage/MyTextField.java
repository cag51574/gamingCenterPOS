package com.mypackage;

import javafx.scene.control.TextField;

public class MyTextField extends TextField{
    MyTextField(){
        super();
        setStyle("-fx-background-color: #000000;-fx-border-color: #0099FF;-fx-text-inner-color: #0099FF;");
    };
}
